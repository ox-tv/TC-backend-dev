<?php

return [
    'api_key' => env('COINMARKETCAP_API_KEY', ''),
    'status' => env('COINMARKETCAP_STATUS', 'off'),


];
