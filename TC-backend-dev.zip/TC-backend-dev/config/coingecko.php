<?php

return [
    'api_key' => env('COINGECKO_API_KEY', ''),
    'status' => env('COINGECKO_STATUS', 'off'),

];
