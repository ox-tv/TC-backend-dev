<?php

return [

    'min_balance_for_monetization_multiplier' => [
        0 => 0,
        1000000 => 1,
        1500000 => 1.1,
        2000000 => 1.2,
        2500000 => 1.3,
        3000000 => 1.5,
    ],

];
