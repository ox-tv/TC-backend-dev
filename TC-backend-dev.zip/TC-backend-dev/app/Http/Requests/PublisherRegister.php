<?php

namespace App\Http\Requests;

use App\Models\Channel;
use App\Models\User;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class PublisherRegister extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'email' => [
                'required', 'string', 'email', 'max:255',
                function($attribute, $value, $fail){
                    // check if user is deleted
                    $user = User::where('email', $value)->first();
                    if ($user && $user->deleted_at) {
                        $fail(__('users.validation.account_deleted'));
                    }
                },
                Rule::unique('users', 'email')->whereNotNull('email_verified_at')],
            'password' => ['required', 'string', 'min:8'],
            'channel_name' => [
                'required',
                Rule::unique('channels', 'name')
            ],
            'platform' => 'required',
        ];
    }

}
