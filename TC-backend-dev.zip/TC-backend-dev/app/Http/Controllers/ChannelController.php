<?php

namespace App\Http\Controllers;

use App\Events\Channels\ChannelUpdated;
use App\Events\ChannelSubscribed;
use App\Exports\PublisherEarningsExport;
use App\Http\Requests\ChannelStore;
use App\Http\Requests\ChannelUpdate;
use App\Http\Resources\Channel\ChannelResource;
use App\Models\Channel;
use App\Models\Earning;
use App\Models\Monetization;
use App\Models\MonetizationPayout;
use App\Models\MonetizePoint;
use App\Models\User;
use App\Services\_2FAService;
use App\Services\EmailVerificationService;
use Carbon\Carbon;
use Carbon\CarbonPeriod;
use Illuminate\Http\Request;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Str;
use Maatwebsite\Excel\Facades\Excel;

class ChannelController extends Controller
{
    private $_2faService;
    private $EmailVerificationService;

    public function __construct(_2FAService $_2faService, EmailVerificationService $EmailVerificationService)
    {
        $this->_2faService = $_2faService;
        $this->EmailVerificationService = $EmailVerificationService;
    }

    public function index(Request $request)
    {
        $perPage = $request->get('per_page') ?: 15;
        $isAdmin = $request->is('api/admin/channels');

        if($isAdmin){
            $query = Channel::query();
        }else{
            $query = Channel::published();
        }

        $filters = $request->get('filters', []);

        $searchFilter = Arr::get($filters, 'search');
        $onlyDeletedFilter = Arr::get($filters, 'only_deleted');

        if($searchFilter){
            $query->where(function ($query) use ($searchFilter) {
                $query->SearchByOwner($searchFilter);
            })->orWhere(function ($query) use($searchFilter) {
                $query->SearchTitle($searchFilter);
            });
        }

        if ($onlyDeletedFilter){
            $query->onlyTrashed()->with('owner');
        }

        $sort = $request->get('sort');
        if($sort === 'most_uploads'){
            $query->withCount('videos')->orderBy('videos_count', 'desc');
        }elseif ($sort === 'most_subscribers'){
            $query->withCount('subscribers')->orderBy('subscribers_count', 'desc');
        }elseif ($sort === 'most_points'){
            $query->orderBy('points', 'desc');
        }elseif ($sort === 'most_comments'){
            $query->withCount('comments')->orderBy('comments_count', 'desc');
        }elseif ($sort === 'last_deleted'){
            $query->orderBy('deleted_at', 'desc');
        }else{
            $query->orderBy('created_at', 'desc');
        }

        $channels = $query->paginate($perPage);

        if ($isAdmin){
            $channels->load(['owner'])->append(['subscribers_count', 'uploads_count', 'total_views', 'total_likes', 'total_comments', 'referrals_count']);
        }else{
            $channels->append(['is_subscribed', 'subscribers_count']);
        }

        if ($onlyDeletedFilter){
            $channels->append(['deleted_at']);
            $channels->each(function ($item, $key) {
                $item->owner->append(['deletion_feedback']);
            });
        }

        return ChannelResource::collection($channels);
    }

    public function show(Request $request, $idOrSlug = null)
    {
        $adminPanel = $request->is('api/admin/*');
        $publisherPanel = $request->is('api/publisher/*');

        $channel = Channel::when($idOrSlug, function ($q, $idOrSlug){
                $q->idOrSlug($idOrSlug);
            })
            ->when(!$idOrSlug, function ($q){
                $q->where('user_id', auth('api')->id());
            })
            ->firstOrFail();

        $channel->load(['language']);

        if ($adminPanel || $publisherPanel){
            $channel->append([
                'is_subscribed',
                'subscribers_count',
                'uploads_count',
                'total_views',
                'watch_time',
                'total_likes',
                'total_dislikes',
                'total_comments',
                'hero_subscribers_count',
                'monetization_qualified_at',
            ]);

            if ($adminPanel){
                $channel->load(['owner']);
            }
        }else{
            $channel->append(['is_subscribed', 'subscribers_count']);
        }

        return ChannelResource::make($channel);
    }

    public function store(ChannelStore $request)
    {
        $channel = new Channel();

        $channel->name = $request->get('name');
        $channel->description = $request->get('description');
        $channel->slug = Str::slug($request->get('name'));

        $channel->cover_url = $request->get('cover');
        $channel->avatar_url = $request->get('avatar');

        if($request->get('intro_video_id')){
            $channel->intro_video_id = $request->get('intro_video_id');
        }

        if($request->is('api/admin/channels')){
            $channel->user_id = $request->get('user_id');
        }else{
            $channel->user_id = auth('guard')->id();
        }

        if($request->get('language')){
            $channel->language_id = $request->get('language');
        }

        $channel->slogan = $request->get('slogan', $channel->slogan);

        $channel->website = $request->get('website', $channel->website);
        $channel->instagram = $request->get('instagram', $channel->instagram);
        $channel->facebook = $request->get('facebook', $channel->facebook);
        $channel->twitter = $request->get('twitter', $channel->twitter);
        $channel->telegram = $request->get('telegram', $channel->telegram);
        $channel->reddit = $request->get('reddit', $channel->reddit);
        $channel->linkedin = $request->get('linkedin', $channel->linkedin);
        $channel->tiktok = $request->get('tiktok', $channel->tiktok);


        if($request->is('api/admin/channels') && $request->get('status')){
            $channel->status = array_flip(Channel::STATUS_TEXT)[$request->get('status')];
        }


        $channel->save();

        $user = $channel->owner;
        $user->username = $channel->name;
        $user->referral_code = str_replace('-','', Str::slug($channel->name));
        $user->avatar_url = $channel->avatar_url;
        $user->save();

        return ChannelResource::make($channel);

    }

    public function update(ChannelUpdate $request, Channel $channel)
    {
        if(!$request->is('api/admin/channels/*')){
            $user = auth('api')->user();

            $_2fa = $user->_2fa;

            if ($_2fa && ($_2fa->app_status || $_2fa->email_status)){
                // 2FA verification
                $errors = [];
                $_2faResult = $this->_2faService->check2FA($user, ['ip' => $request->ip()]);

                if (($_2fa->app_status && !$_2faResult['app']) || ($_2fa->email_status && !$_2faResult['email'])){
                    $errors['app'] = $_2fa->app_status? 'Please verify app 2FA' : null;
                    $errors['email'] = $_2fa->email_status? 'Please verify email 2FA' : null;
                }

                if (!empty($errors)){
                    return response()->json([
                        'message' => 'Please verify 2FA',
                        'code' => '2fa.require',
                        'errors' => $errors
                    ], 403);
                }

            }else if (!$this->EmailVerificationService->check($user)){
                // Email Verification
                $this->EmailVerificationService->sendCode($user);
                return response()->json([
                    'message' => 'Please pass email verification',
                    'code' => 'email_verification.require',
                ], 403);
            }
        }

        if(is_null($request->route('channel'))){
            $channel = auth('api')->user()->channel;
        }

        if(!$request->is('api/admin/channels/*') && $channel->owner->id != auth('api')->id()){
            abort(403, 'You do not have permission to access');
        }

        $oldChannel = clone $channel;

        $channel->name = $request->get('name', $channel->name);
        $channel->description = $request->get('description', $channel->description);

        $channel->slug = $request->get('slug')? $request->get('slug'): Str::slug($request->get('name', $channel->name));

        $channel->cover_url = $request->get('cover', $channel->cover_url);
        $channel->avatar_url = $request->get('avatar', $channel->avatar_url);

        if($request->get('intro_video_id')){
            $channel->intro_video_id = $request->get('intro_video_id');
        }

        if($request->get('language')){
            $channel->language_id = $request->get('language');
        }

        $channel->slogan = $request->get('slogan', $channel->slogan);

        $channel->website = $request->get('website', $channel->website);
        $channel->instagram = $request->get('instagram', $channel->instagram);
        $channel->facebook = $request->get('facebook', $channel->facebook);
        $channel->twitter = $request->get('twitter', $channel->twitter);
        $channel->telegram = $request->get('telegram', $channel->telegram);
        $channel->reddit = $request->get('reddit', $channel->reddit);
        $channel->linkedin = $request->get('linkedin', $channel->linkedin);
        $channel->tiktok = $request->get('tiktok', $channel->tiktok);


        if($request->is('api/admin/channels/*') && $request->get('status')){
            $channel->status = array_flip(Channel::STATUS_TEXT)[$request->get('status')];
        }

        if($request->is('api/admin/channels/*') && $request->get('points')){
            $channel->points = $request->get('points');
        }

        $channel->save();

        $user = $channel->owner;
        $user->username = $channel->name;
        $user->referral_code = str_replace('-','', Str::slug($channel->name));
        $user->avatar_url = $channel->avatar_url;
        $user->save();

        event(new ChannelUpdated($oldChannel, $channel));

        return ChannelResource::make($channel);
    }

    public function destroy(Channel $channel)
    {
        $channel->delete();
    }

    public function subscription(Channel $channel){

        $user = Auth::user();

        $subscribedBefore = $channel->subscribers()->where('id', $user->id)->exists();

        if($subscribedBefore){
            $channel->subscribers()->detach(auth('api')->user());
        }else{
            $channel->subscribers()->attach(auth('api')->user());
        }

        Cache::forget("user{$user->id}_subscribedChannelIds");

        $channel->append(['is_subscribed']);

        event(new ChannelSubscribed(
            $channel,
            auth('api')->user(),
            $subscribedBefore?0:1,
            $subscribedBefore?1:0));

        return ChannelResource::make($channel);
    }

    public function performanceTotal(Request $request, User $user = null)
    {
        if (!$request->is('api/admin/*')){
            $user = auth('api')->user();
        }

        $filters = $request->get('filters', []);
        $from = Arr::get($filters, 'from');
        $to = Arr::get($filters, 'to');

        $monetizationIds = Monetization::when($from, function ($q, $from){
            $q->where('month', '>=', $from);
        })->when($to, function ($q, $to){
            $q->where('month', '<=', $to);
        })->pluck('id')->toArray();
        $MonetizationPayoutsAmount = MonetizationPayout::when($user, function($q, $user){$q->where('channel_id', $user->channel->id);})
            ->whereIn('monetization_id', $monetizationIds)->sum('amount');
//        $earningAmount = Earning::where('user_id', $user->id)->when($from, function ($q, $from){
//                $q->where('date', '>=', $from);
//            })->when($to, function ($q, $to){
//                $q->where('date', '<=', $to);
//            })->sum('amount');

        // Calc total points
        $pointsQuery = MonetizePoint::
            when($from, function ($q) use ($from){
                $q->where('date', '>=', Carbon::parse($from));
            })->when($to, function ($q) use ($to){
                $q->where('date', '<=', Carbon::parse($to));
            });

        $result = [
            'points_total' => intval($pointsQuery->sum('amount')),
            'points_channel' => intval($pointsQuery->where('channel_id', $user->channel->id)->sum('amount')),
            'earning_channel' => intval($MonetizationPayoutsAmount),
        ];

        return response()->json($result);
    }

    public function performanceMonthly(Request $request, User $user = null)
    {
        if (!$request->is('api/admin/*')){
            $user = auth('api')->user();
        }

        $result = [];

        $filters = $request->get('filters', []);
        $from = Arr::get($filters, 'from', (Carbon::now())->subMonths(12)->firstOfMonth()->format('Y-m-d'));
        $to = Arr::get($filters, 'to', (Carbon::now())->firstOfMonth()->format('Y-m-d'));
        $monthPeriods = CarbonPeriod::create($from, '1 month', $to);

        foreach ($monthPeriods as $month) {
            $from_day = $month->copy()->startOfMonth()->format("Y-m-d H:i:s");
            $to_day = $month->copy()->endOfMonth()->format("Y-m-d H:i:s");

            $monetization = Monetization::whereDate('month', $month->copy()->startOfMonth())->first();
            $MonetizationPayoutsAmount = MonetizationPayout::when($user, function($q, $user){$q->where('channel_id', $user->channel->id);})
                ->where('monetization_id', $monetization->id??0)->sum('amount');
//            $earningAmount = Earning::where('user_id', $user->id)
//                ->whereDate('date', $month->copy()->startOfMonth()->format("Y-m-d"))
//                ->sum('amount');

            $pointsTotal = MonetizePoint::where('channel_id', $user->channel->id)
                ->where('date', '>=', Carbon::parse($from_day))
                ->where('date', '<=', Carbon::parse($to_day))
                ->sum('amount');

            $result[$month->format("Y-m")] = [
                'date' => $month->format("Y-m"),
                'points_hero' => 0,
                'points_non_hero' => 0,
                'points_total' => intval($pointsTotal),
                'earning' => intval($MonetizationPayoutsAmount),
            ];
        }


        if (in_array($user->id, [4610, 4611, 12])){
            $rawData = [
                'January' => [
                    'points' => 8620,
                    'earning' => 249,
                ],
                'February' => [
                    'points' => 11710,
                    'earning' => 341,
                ],
                'March' => [
                    'points' => 9395,
                    'earning' => 328,
                ],
                'April' => [
                    'points' => 13190,
                    'earning' => 462,
                ],
                'May' => [
                    'points' => 12275,
                    'earning' => 448,
                ],
                'June' => [
                    'points' => 2958,
                    'earning' => 98,
                ],
                'July' => [
                    'points' => 3586,
                    'earning' => 107,
                ],
                'August' => [
                    'points' => 3971,
                    'earning' => 124,
                ],
                'September' => [
                    'points' => 3785,
                    'earning' => 114,
                ],
                'October' => [
                    'points' => 5215,
                    'earning' => 137,
                ],
                'November' => [
                    'points' => 6275,
                    'earning' => 176,
                ],
                'December' => [
                    'points' => 7840,
                    'earning' => 182,
                ],
            ];

            foreach ($monthPeriods as $month) {
                $monthName = $month->startOfMonth()->format("F");

                $result[$month->format("Y-m")] = [
                    'date' => $month->format("Y-m"),
                    'points_hero' => 0,
                    'points_non_hero' => 0,
                    'points_total' => $rawData[$monthName]['points'],
                    'earning' => $rawData[$monthName]['earning'],
                ];
            }
        }

        return response()->json($result);
    }

    public function exportPublishersEarnings(Request $request)
    {
        $filters = $request->get('filters', []);
        $monthFilter = Arr::get($filters, 'month');

        $month = null;
        if ($monthFilter){
            $month = Carbon::parse($monthFilter);
        }

        $users = User::whereHas('channel')->get();

        foreach ($users as $user){

            $user->channelName = $user->channel->name?? '';

            $earning = Earning::where('user_id', $user->id)
                ->when(!empty($month), function ($query) use ($month) {
                    return $query->whereYear('created_at', $month->year)
                        ->whereMonth('created_at', $month->month);
                })->first();
            $user->earningStatus = $earning?Earning::STATUS_TEXT[$earning->status]:'N/A';
            $user->earningAmount = $earning->amount?? 0;
        }

        $fileName = 'publishers-earnings'.((!empty($month))?'-'.$month->format('Y-m'):'').'.xlsx';

        return Excel::download(new PublisherEarningsExport($users), $fileName);
    }

}
