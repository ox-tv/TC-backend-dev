<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Http\Resources\_2FA\_2FAResource;
use App\Http\Resources\User\UserResource;
use App\Models\_2FA;
use App\Models\AuthKey;
use App\Models\User;
use App\Services\_2FAService;
use BaconQrCode\Renderer\Image\ImagickImageBackEnd;
use BaconQrCode\Renderer\ImageRenderer;
use BaconQrCode\Renderer\RendererStyle\RendererStyle;
use BaconQrCode\Writer;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use PragmaRX\Google2FA\Google2FA;

class _2FAController extends Controller
{
    private $_2faService;

    public function __construct(_2FAService $_2faService)
    {
        $this->_2faService = $_2faService;
    }

    public function user2FA()
    {
        $user =  auth('api')->user();

        return $user->_2fa? _2FAResource::make($user->_2fa): null;
    }

    // Verify
    public function verify(Request $request)
    {
        if ($request->header('tc-auth-key')){
            $request->merge(['auth-key' => $request->header('tc-auth-key')]);
        }

        if (auth('api')->check()){

            $user = auth('api')->user();

        }else if ($request->get('auth-key')){

            $request->validate([
                'auth-key' => [
                    'required',
                    function ($attribute, $value, $fail) {
                        if ($value && !AuthKey::where('auth_key', $value)->exists()) {
                            $fail('The '.$attribute.' is invalid.');
                        }
//                        if ($value && !Cache::has($value)) {
//                            $fail('The '.$attribute.' is invalid.');
//                        }
                    },
                ],
            ]);

            $authKeyModel = AuthKey::where('auth_key', $request->get('auth-key'))->first();
            $user = $authKeyModel->user()->firstOrFail();

//            $userId = Cache::get($request->get('auth-key'));
//            $user = User::where('id', $userId)->firstOrFail();
        }else{
            return response()->json([
                "message" => "Unauthenticated."
            ], 401);
        }

        $_2fa = $user->_2fa;
        $emailValidations = [];
        $appValidations = [];
        if ($_2fa && $_2fa->app_status){
            $appValidations = ['required'];
        }
        if ($_2fa && $_2fa->email_status){
            $emailValidations = ['required'];
        }

        $request->validate([
            'email_2fa_code' => $emailValidations,
            'app_2fa_secret' => $appValidations,
        ]);

        $data = [];
        $mapKeys = [
            'email_2fa_code' => 'email',
            'app_2fa_secret' => 'app',
        ];
        foreach ($request->only(['email_2fa_code', 'app_2fa_secret']) as $k => $v){
            $data[$mapKeys[$k]] = $v;
        }

        $result = $this->_2faService->verify($user, $data);

        $errors = [];
        if (!empty($data['app']) && !$result['app']){
            $errors['app_2fa_secret'] = 'Invalid/ expired code.';
        }

        if (!empty($data['email']) && !$result['email']){
            $errors['email_2fa_code'] = 'Invalid/ expired code.';
        }

        if (!empty($errors)) {
            return response()->json([
                'message' => 'verify failed.',
                'code' => '2fa.verify.fail',
                'errors' => $errors
            ], 422);
        }

        if ($request->get('auth-key')){
            return response()->json([
                'status' => 'ok',
                'profile' => UserResource::make($user->append('role_name')),
                'token' =>  $user->createToken('access_token')->accessToken,
            ]);
        }

        return response()->json(['status' => 'ok']);
    }

    // Email 2FA
    public function sendEmail2FACode(Request $request)
    {
        if ($request->header('tc-auth-key')){
            $request->merge(['auth-key' => $request->header('tc-auth-key')]);
        }

        if (auth('api')->check()){

            $user = auth('api')->user();

        }else if ($request->get('auth-key')){

            $request->validate([
                'auth-key' => [
                    'required',
                    function ($attribute, $value, $fail) {
                        if ($value && !AuthKey::where('auth_key', $value)->exists()) {
                            $fail('The '.$attribute.' is invalid.');
                        }
//                        if ($value && !Cache::has($value)) {
//                            $fail('The '.$attribute.' is invalid.');
//                        }
                    },
                ],
            ]);
            $authKeyModel = AuthKey::where('auth_key', $request->get('auth-key'))->first();
            $user = $authKeyModel->user()->firstOrFail();
//            $userId = Cache::get($request->get('auth-key'));
//            $user = User::where('id', $userId)->firstOrFail();

        }else{
            return response()->json([
                "message" => "Unauthenticated."
            ], 401);
        }

        $this->_2faService->sendEmail2FACode($user);

        return response()->json(['status' => 'ok']);
    }

    public function enableEmail2FA(Request $request)
    {
        $user = auth('api')->user();
        $_2fa = $user->_2fa;

        if (!$_2fa){
            $_2fa = new _2FA();
            $_2fa->user_id = $user->id;
        }

        $result = $this->_2faService->check2FA($user, ['ip' => $request->ip()]);

        if (($_2fa->app_status && !$result['app']) || !$result['email']){
            return response()->json([
                'message' => 'Please verify 2FA.',
                'code' => '2fa.require',
                'errors' => [
                    'app' => $_2fa->app_status? 'Please verify app 2FA' : null,
                    'email' => 'Please verify email 2FA'
                ]
            ], 403);
        }

        $_2fa->email_status = _2FA::EMAIL_STATUS_ENABLE;
        $_2fa->save();

        return response()->json(['status' => 'ok']);
    }

    public function disableEmail2FA(Request $request)
    {
        $user = auth('api')->user();
        $_2fa = $user->_2fa;

        $_2fa->email_status = _2FA::EMAIL_STATUS_DISABLE;
        $_2fa->email_verified_at = null;
        $_2fa->save();

        return response()->json(['status' => 'ok']);
    }

    // GOOGLE 2FA
    public function getApp2FAQrCode()
    {
        $user = auth('api')->user();
        $google2FAClient = new Google2FA();

        if (!($_2fa = $user->_2fa)){
            $_2fa = new _2FA();
            $_2fa->user_id = $user->id;
        }else if ($_2fa->app_status == _2FA::APP_STATUS_ENABLE && $_2fa->app_type == _2FA::APP_TYPE_GOOGLE){
            return response()->json([
                'message' => 'Google 2FA has already been enabled',
                'code' => '2fa.google.already_enabled',
            ], 400);
        }

        $_2fa->app_status = _2FA::APP_STATUS_DISABLE;
        $_2fa->app_type = _2FA::APP_TYPE_GOOGLE;
        $_2fa->app_secret = $google2FAClient->generateSecretKey();
        $_2fa->save();

        // Create QRCode for Scan on App
        $qrCodeUrl = $google2FAClient->getQRCodeUrl(
            config('general.SITE_NAME'),
            $user->email,
            $_2fa->app_secret
        );

        $writer = new Writer(
            new ImageRenderer(
                new RendererStyle(400),
                new ImagickImageBackEnd()
            )
        );

        $qrcode_image = 'data:image/png;base64,' . base64_encode($writer->writeString($qrCodeUrl));

        return response()->json(['qrcode' => $qrcode_image, 'key' => $_2fa->app_secret]);
    }

    public function enableGoogle2FA(Request $request)
    {
        $user = auth('api')->user();

        $result = $this->_2faService->check2FA($user, ['ip' => $request->ip()]);

        if (!$result['app'] || !$result['email']){
            return response()->json([
                'message' => 'Please verify 2FA.',
                'code' => '2fa.require',
                'errors' => [
                    'app' => 'Please verify google 2FA',
                    'email' => 'Please verify email 2FA'
                ]
            ], 403);
        }

        $_2fa = $user->_2fa;
        $_2fa->app_status = _2FA::APP_STATUS_ENABLE;
        $_2fa->save();

        return response()->json(['status' => 'ok']);
    }

    public function disableGoogle2FA(Request $request)
    {
        $user = auth('api')->user();
        $_2fa = $user->_2fa;

        $_2fa->app_status = _2FA::APP_STATUS_DISABLE;
        $_2fa->app_verified_at = null;
        $_2fa->app_type = null;
        $_2fa->app_secret = null;
        $_2fa->save();

        return response()->json(['status' => 'ok']);
    }
}
