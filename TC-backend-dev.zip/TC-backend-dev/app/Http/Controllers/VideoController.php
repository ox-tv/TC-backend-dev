<?php

namespace App\Http\Controllers;

use App\Events\Comments\CommentCreated;
use App\Events\VideoCreated;
use App\Events\VideoDeleted;
use App\Events\VideoUpdated;
use App\Events\VideoViewed;
use App\Events\VideoWasHidden;
use App\Events\VideoWasUnHidden;
use App\Events\VideoWatched;
use App\Http\Requests\VideoComment;
use App\Http\Requests\VideoStore;
use App\Http\Requests\VideoUpdate;
use App\Http\Requests\WatchTimeStore;
use App\Http\Resources\Comment\CommentResource;
use App\Http\Resources\CryptoCurrency\CryptoCurrencyResource;
use App\Http\Resources\Video\VideoResource;
use App\Http\Resources\VideoCollection;
use App\Models\Category;
use App\Models\ChannelUser;
use App\Models\Comment;
use App\Models\CommentUser;
use App\Models\CryptoCurrency;
use App\Models\Language;
use App\Models\Option;
use App\Models\Playlist;
use App\Models\Scopes\OrderDescScope;
use App\Models\Tag;
use App\Models\User;
use App\Models\Video;
use App\Models\VideoMeta;
use App\Models\WatchTime;
use App\Models\WatchTimeMongo;
use App\Repository\Eloquent\TagRepository;
use App\Repository\Eloquent\VideoRepository;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;

class VideoController extends Controller
{
    private $videoRepository;
    private $tagRepository;

    public function __construct(
        VideoRepository $videoRepository,
        TagRepository $tagRepository
    )
    {
        $this->videoRepository = $videoRepository;
        $this->tagRepository = $tagRepository;
    }

    /**
     * Display a listing of the resource.
     *
     * @param Request $request
     * @return VideoCollection
     */
    public function index(Request $request)
    {
        $perPage = $request->get('per_page') ?: 15;
        $publisherVideos = $request->is('api/publisher/videos');
        $adminVideos = $request->is('api/admin/videos');

        if($publisherVideos){
            $query = Video::mine();
        }else if($adminVideos){
            $query = Video::query();
        }else{
            $query = Video::published();
        }

        $filters = $request->get('filters', []);

        $timeFilter = Arr::get($filters, 'time');
        $searchFilter = Arr::get($filters, 'search');
        $mediaTypeFilter = Arr::get($filters, 'media_type');
        $categoryId = Arr::get($filters, 'category_id');
        $categorySlug = Arr::get($filters, 'category_slug');
        $cryptoCurrencyId = Arr::get($filters, 'cryptocurrency_id');
        $cryptoCurrencySlug = Arr::get($filters, 'cryptocurrency_slug');
        $playlistId = Arr::get($filters, 'playlist');
        $playlistHash = Arr::get($filters, 'playlist_hash');
        $channelId = Arr::get($filters, 'channel');
        $channelSlug = Arr::get($filters, 'channel_slug');

        if($mediaTypeFilter && !empty(array_flip(Video::MEDIA_TYPE_TEXT)[$mediaTypeFilter])){
            $query->where('media_type', array_flip(Video::MEDIA_TYPE_TEXT)[$mediaTypeFilter]);
        }

        if($categorySlug){
            $category = Category::where('slug', $categorySlug)->firstOrFail();
            $categoryId = $category->id;
        }

        if($playlistHash){
            $playlist = Playlist::where('url_hash', $playlistHash)->firstOrFail();
            $playlistId = $playlist->id;
        }

        if($cryptoCurrencySlug){
            $cryptoCurrency = CryptoCurrency::where('slug', $cryptoCurrencySlug)->firstOrFail();
            $cryptoCurrencyId = $cryptoCurrency->id;
        }

        if($timeFilter){
            switch ($timeFilter){
                case 'week':{
                    $query->week();
                    break;
                }
                case 'last_hour':{
                    $query->lastHour();
                    break;
                }
                case 'last_day':{
                    $query->lastDay();
                    break;
                }
                case 'last_week':{
                    $query->lastweek();
                    break;
                }
                case 'last_month':{
                    $query->lastMonth();
                    break;
                }
                case 'last_season':{
                    $query->lastSeason();
                    break;
                }
                default:{

                }
            }
        }

        if($searchFilter){
            $query->where(function ($query) use ($searchFilter){
                $query->where(function ($query) use ($searchFilter){
                    $query->SearchTitle($searchFilter);
                })->orWhere(function ($query) use ($searchFilter){
                    $query->SearchDescription($searchFilter);
                });
            });
        }

        if($categoryId){
            $query->filterCategory($categoryId);
        }

        if(!empty($cryptoCurrencyId)){
            $query->filterCryptoCurrency($cryptoCurrencyId);
        }

        if($playlistId){
            $query->inPlaylist($playlistId);
        }

        $excludedVideos = [];

        $excludePlaylistsId = $request->get('exclude_playlist');
        if($excludePlaylistsId){
            $playlistVideos = Playlist::find($excludePlaylistsId)->videos()->select('id')->get()->pluck('id')->toArray();
            $excludedVideos = array_merge($excludedVideos, $playlistVideos);
        }

        $excludeVideosIds = $request->get('exclude_videos', []);
        if(count($excludeVideosIds)>0){
            $excludedVideos = array_merge($excludedVideos, $excludeVideosIds);
        }

        if(count($excludedVideos) > 0){
            $query->whereNotIn('id', $excludedVideos);
        }

        if($channelId){
            $query->inChannel($channelId);
        }

        if($channelSlug){
            $query->whereHas('channel', function($q) use ($channelSlug){
                return $q->where('slug', $channelSlug);
            });
        }

        $sort = $request->get('sort');
        if($sort === 'most_liked'){
            $query->withCount(['likedBy', 'dislikedBy'])->orderByRaw('(liked_by_count - disliked_by_count) DESC');
        }elseif ($sort === 'most_viewed'){
            $query->orderBy('view_count', 'desc');
        }elseif ($sort === 'most_commented'){
            $query->withCount('comments')->orderBy('comments_count', 'desc');
        }elseif (($channelId || $channelSlug) && $request->is('api/videos')){
            $query->withoutGlobalScope(OrderDescScope::class)->orderBy('published_at', 'desc');
        }else{
            $query->withoutGlobalScope(OrderDescScope::class)->orderBy('published_at', 'desc');
        }

        $videos = $query->paginate($perPage);

        if ($publisherVideos) {
            $relations = ['playlists', 'category'];
            $attributes = ['comment_count', 'rating'];
        }elseif ($adminVideos) {
            $relations = ['channel', 'category'];
            $attributes = ['comment_count', 'likes_count', 'reports_count'];
        }else{
            $relations = ['channel'];
            $attributes = ['is_bookmarked'];
        }

        $videos->load($relations)->append($attributes);

        $result = VideoResource::collection($videos);

        if($categorySlug){
            $result->additional([
                'category' => $categorySlug == "all" ? "All" : $category->name
            ]);
        }

        if($cryptoCurrencySlug){
            $result->additional([
                'cryptocurrency' => CryptoCurrencyResource::make($cryptoCurrency)
            ]);
        }

        return $result;
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     */
    public function store(VideoStore $request)
    {
        $video = new Video();

        $video->title = $request->get('title');
        $video->slug = Str::slug($request->get('title'));
        $video->description = $request->get('description');
        $video->published_at = $request->get('published_at');

        // adding user to video
        if($request->is('api/admin/videos')){
            $video->user_id = $request->get('user_id');
        }else{
            $video->user_id = auth('api')->user()->id;
        }

        if($request->is('api/admin/videos')){

            $video->file_path = $request->get('video_name');

        }elseif($request->get('youtube_link')){

            $video->youtube_link = $request->get('youtube_link');
            $video->upload_method = Video::UPLOAD_METHOD_YOUTUBE;

        }elseif($request->file('video')){ // adding file to video

            $videoFile = Storage::disk('videos')->put('/', $request->file('video'));
            $video->file_path = $videoFile;

        }elseif($request->get('file_url')){ // adding file to video
            $user = User::find($video->user_id);
            $channel = $user->channel;
            $directory = "channel/{$channel->id}/videos";
            $r2Url = uploadFileToR2ByUrl($request->get('file_url'), $directory);
            $video->file_url = $r2Url;
        }

        // thumbnail
        $video->thumbnail_url = $request->get('thumbnail');

        // status
        if($request->get('status')){
            $video->status = array_flip(Video::STATUS_TEXT)[$request->get('status')];
        }

        // media type
        if($request->get('media_type')){
            $video->media_type = array_flip(Video::MEDIA_TYPE_TEXT)[$request->get('media_type')];
        }

        // duration
        if($request->get('duration')){
            $video->duration = $request->get('duration');
        }

        // adding main category
        if($request->get('category')){
            $video->category()->associate($request->get('category'));
        }

        if($request->get('language')){
            $video->language_id = $request->get('language');
        }


        DB::transaction(function () use ($request, $video){

            $video->save();

            // adding categories
            if($request->get('categories')){
                $video->categories()->saveMany(Category::whereIn('id', $request->get('categories'))->get());
            }

            // adding crypto currencies
            if($request->get('crypto_currencies')){
                $video->crypto_currencies()->sync($request->get('crypto_currencies'));
            }

            // adding tags
            if($request->get('tags')){
                $tags = collect($request->get('tags', []));

                $tags->map(function ($tag) use ($video){
                    $video->tags()->save($this->tagRepository->store([
                        'name' => $tag,
                        'status' => Tag::STATUS_PUBLISHED,
                        'creation_scope' => Tag::CREATION_SCOPE_USER,
                    ]));
                });
            }

            // adding playlist
            if($request->get('playlists')){
                $video->playlists()->saveMany(Playlist::whereIn('id', $request->get('playlists'))->get());
            }

            if($request->get('comment_text')){
                $comment = new Comment();
                $comment->text = $request->get('comment_text');
                $comment->user_id = $video->user_id;
                $comment->is_pinned = Comment::COMMENT_PINNED;
                $comment->pinned_by = $video->user_id;
                $comment->video()->associate($video->id);
                $comment->save();
            }
        });

        event(new VideoCreated($video));

        return new VideoResource($video);
    }

    /**
     * Display the specified resource.
     *
     * @param mixed $id_or_url_hash
     * @param Request $request
     */
    public function show($id_or_url_hash, Request $request)
    {
        $video = Video::idOrUrlHash($id_or_url_hash)
            ->when($request->is('api/videos/*'), function ($query){
                $query->publishedOnceWithTrashed();
            })
            ->when($request->is('api/publisher/videos/*'), function ($query){
                $query->mine();
            })
            ->firstorFail();

        if (
            !$request->is('api/admin/videos/*') &&
            (
                $video->user_id != auth('api')->id() &&
                (
                    !is_null($video->published_at)
                    && (!is_null($video->deleted_at) || $video->status != Video::STATUS_PUBLISHED)
                )
            )
        ){
            return response()->json([
                'message' => __('video.media_is_no_longer_available'),
                'code' => 'media_is_no_longer_available',
            ], 404);
        }

        $video->load([
                'user',
                'channel',
                'category',
                'language',
                'crypto_currencies',
                'tags',
                'playlists',
                'subtitles.language',
                'chapters',
                'meta',
            ])
            ->append([
                'rating',
                'comment_count',
                'likes_count',
                'dislikes_count',
                'reports_count',
                'is_liked',
                'is_disliked',
                'is_bookmarked',
                'layers',
            ]);

        if ($request->is('api/publisher/*') && !$video->published_at){
            $video->append(['pinned_comment']);
        }

        $video->channel->append(['is_subscribed', 'subscribers_count']);

        return VideoResource::make($video);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param Video $video
     */
    public function update(VideoUpdate $request, Video $video)
    {
        $oldVideo = clone $video;

        // updating title
        if($request->get('title')){
            $video->title = $request->get('title');

            if(!$request->get('slug')){
                $video->slug = Str::slug($request->get('title'));
            }
        }

        // updating slug
        if($request->get('slug')){
            $video->slug = Str::slug($request->get('slug'));
        }

        if($request->get('description')){
            $video->description = $request->get('description');
        }

        // thumbnail
        if ($request->get('thumbnail')){
            $video->thumbnail_url = $request->get('thumbnail');
        }

        // status
        if($request->get('status') && $oldVideo->status != Video::STATUS_HIDDEN){
            $video->status = array_flip(Video::STATUS_TEXT)[$request->get('status')];
        }

        if($request->get('media_type')){
            $video->media_type = array_flip(Video::MEDIA_TYPE_TEXT)[$request->get('media_type')];
        }

        // adding main category
        if($request->get('category')){
            $video->category()->associate($request->get('category'));
        }

        if($request->get('language')){
            $video->language_id = $request->get('language');
        }else{
            $video->language_id = Language::where('code', 'en')->first()->id ?? null;
        }


        DB::transaction(function () use ($request, $video){

            $video->save();

            if ($video->status == Video::STATUS_PUBLISHED){
                $studioDraftData = $video->meta()->where('key', VideoMeta::VIDEO_STUDIO_DRAFT)->first();
                $studioDraftData && $video->meta()->updateOrCreate(
                    ['key' => VideoMeta::VIDEO_STUDIO],
                    ['value' => $studioDraftData->value? json_encode($studioDraftData->value): $studioDraftData->value]
                );
            }

            // updating categories
            if($request->get('categories')){
                if(is_array($request->get('categories'))){
                    $video->categories()->sync(Category::whereIn('id', $request->get('categories'))->get());
                }else{
                    $video->categories()->sync(Category::where('id', $request->get('categories'))->get());
                }
            }

            // updating crypto currency
            if($request->get('crypto_currencies')){
                $video->crypto_currencies()->sync($request->get('crypto_currencies'));
            }

            // updating tags
            if($request->get('tags')){
                $tags = collect($request->get('tags', []));

                $tagIds = $tags->map(function ($tag){
                    $tag = $this->tagRepository->store([
                        'name' => $tag,
                        'status' => Tag::STATUS_PUBLISHED,
                        'creation_scope' => Tag::CREATION_SCOPE_USER,
                    ]);
                    return $tag->id;
                });

                $video->tags()->sync($tagIds);
            }else{
                $video->tags()->sync([]);
            }

            // adding playlist
            if($request->get('playlists')){
                $video->playlists()->sync(Playlist::whereIn('id', $request->get('playlists'))->get());
            }


            if (!$video->published_at){
                $pinnedComment = $video->pinned_comment;

                if($request->get('comment_text')){
                    if ($pinnedComment){
                        $pinnedComment->text = $request->get('comment_text');
                        $pinnedComment->save();
                    }else{
                        $comment = new Comment();
                        $comment->text = $request->get('comment_text')? : null;
                        $comment->user_id = $video->user_id;
                        $comment->is_pinned = Comment::COMMENT_PINNED;
                        $comment->pinned_by = $video->user_id;
                        $comment->video()->associate($video->id);
                        $comment->save();
                    }
                }else if($pinnedComment){
                    $pinnedComment->delete();
                }
            }

        });

        event(new VideoUpdated($oldVideo, $video));

        return new VideoResource($video);
    }

    public function bulkAssignCategoryToMedia(Request $request)
    {
        $request->validate([
            'category_id' => ['nullable'],
            'media_ids' => ['required', 'array'],
            'media_ids.*' => ['required', Rule::exists('videos', 'id')],
        ]);

        Video::whereIn('id', $request->get('media_ids'))->update([
            'category_id' => $request->get('category_id')
        ]);

        return response()->json(['status' => 'ok']);
    }

    public function changeStatusToPublished($id)
    {
        $beforeUpdate = Video::where('id', $id)->where('user_id', auth('api')->id())->firstOrFail();

        $validator = Validator::make([
            'title' => $beforeUpdate->title,
            'thumbnail' => $beforeUpdate->thumbnail_url,
            'category' => $beforeUpdate->category_id,
            'language' => $beforeUpdate->language_id,
        ], [
            'title' => 'required',
            'thumbnail' => 'required',
            'category' => 'required',
            'language' => 'required',
        ]);

        if ($validator->fails()) {
            return response()->json(['message' => 'Video is not ready to get published.', 'errors' => $validator->errors()], 422);
        }

        $this->videoRepository->update($id, [
            'status' =>Video::STATUS_PUBLISHED
        ]);

        $studioDraftData = $beforeUpdate->meta()->where('key', VideoMeta::VIDEO_STUDIO_DRAFT)->first();
        $studioDraftData && $beforeUpdate->meta()->updateOrCreate(
            ['key' => VideoMeta::VIDEO_STUDIO],
            ['value' => $studioDraftData->value? json_encode($studioDraftData->value): $studioDraftData->value]
        );

        $afterUpdate = Video::where('id', $id)->first();

        event(new VideoUpdated($beforeUpdate, $afterUpdate));

        return response()->json(['status' => 'ok']);
    }

    public function destroy(Request $request, Video $video)
    {
        if(!(request()->is('api/admin/videos/*') || $video->user_id === Auth::guard('api')->id())){
            return response()->json([
                'general.not_authorized'
            ], 403);
        }

        $reasonKey = null;
        $reasonText = null;

        if(request()->is('api/admin/videos/*')){
            $request->validate([
                'reason' => 'required'
            ]);

            $option_key = Option::VIDEO_DELETE_REASONS;
            $reasons = json_decode(Option::where("key", $option_key)->first()->value?? abort(404));


            if(($key = array_search($request->get('reason'), array_column($reasons, 'key'))) !== false ){
                $reasonKey = $request->get('reason');
                $reasonText = $reasons[$key]->value;
            }else{
                $reasonKey = 'other';
                $reasonText = $request->get('reason');
            }
        }

        $this->videoRepository->destroy($video->id, ['reason_key' => $reasonKey, 'reason_text' => $reasonText]);

        event(new VideoDeleted($video));

        return new VideoResource($video);
    }

    public function bookmarks()
    {
        $perPage = request()->get('per_page') ?: 15;

        $videos = auth('api')->user()->bookmarkVideos()
            ->withoutGlobalScope(OrderDescScope::class)->orderBy('published_at', 'desc')
            ->paginate($perPage);

        $videos->load(['channel'])->append(['is_bookmarked']);

        return VideoResource::collection($videos);
    }

    public function subscribedChannelsVideos(Request $request)
    {
        $perPage = $request->get('per_page') ?: 15;

        $subscribedChannelIds = ChannelUser::where('user_id', auth('api')->id())->pluck('channel_id')->toArray();

        $videos = Video::whereIn('channel_id', $subscribedChannelIds)
            ->withoutGlobalScope(OrderDescScope::class)->orderBy('published_at', 'desc')
            ->paginate($perPage);

        $videos->load(['channel'])->append(['is_bookmarked']);

        return VideoResource::collection($videos);
    }

    /**
     * Add comment to a video
     *
     * @param VideoComment $request
     * @param Video $video
     * @return void
     */
    public function storeComment(VideoComment $request, $videoIdOrHash)
    {
        $video = Video::published()->where('id', $videoIdOrHash)->orWhere('url_hash', $videoIdOrHash)->firstOrFail();

        $user = Auth::user();

        $comment = new Comment();
        $comment->text = $request->get('text');
        $comment->user_id = $user->id;
        $comment->video()->associate($video);
        $comment->save();

        if (!empty($request->get('mentions'))){
            foreach ($request->get('mentions') as $id){
                $mentions[$id] = ['relation' => CommentUser::MENTION_RELATION];
            }
            $comment->mentions()->attach($mentions);
        }

        event(new CommentCreated($comment));

        return CommentResource::make($comment);
    }

    public function comments($idOrUrlHash)
    {
        $video = Video::published()
            ->idOrUrlHash($idOrUrlHash)
            ->firstOrFail();

        $comments = $video->comments()->onlyParent()->paginate();

        $comments->load([
            'user.channel',
            'PinnedBy'
        ])->append([
            'is_liked',
            'is_disliked',
            'likes_count',
            'dislikes_count',
            'replies_count'
        ]);

        $comments->each(function ($item, $key) {
            $item->user->append('is_publisher');
        });

        return CommentResource::collection($comments);
    }

    public function bulkDestroy(Request $request){
        $request->validate([
            'videos.*' => 'exists:videos,id'
        ]);

        $videos = Video::whereIn('id', $request->get('videos'));


        $owners = $videos->select('user_id')->get()->pluck('user_id')->unique()->toArray();

        if(count($owners) != 1 || !in_array(Auth::guard('api')->id(), $owners)){

            return response()->json([
                'message' => 'general.not_authorized'
            ], 403);
        }

        foreach ($request->get('videos') as $videoId){
            $this->videoRepository->destroy($videoId);
        }

        return response()->json([
            'message' => 'general.successful'
        ]);

    }

    public function bulkPinMessage(Request $request){
        $request->validate([
            'videos.*' => 'exists:videos,id',
            'text' => 'required'
        ]);

        $userId = Auth::guard('api')->id();
        $videoIds = collect($request->get('videos'));
        $text = $request->get('text');

        Comment::whereIn('video_id', $videoIds)->onlyParent()->update([
            'is_pinned' => false,
            'pinned_by' => null,
        ]);

        $videoIds->map(function ($videoId) use ($userId, $text){
            $comment = new Comment();
            $comment->text = $text;
            $comment->user_id = $userId;
            $comment->video()->associate($videoId);
            $comment->is_pinned = Comment::COMMENT_PINNED;
            $comment->pinned_by = $userId;
            $comment->save();
        });

        return response()->json([
            'message' => 'general.successful'
        ]);

    }

    public function hide(Request $request, Video $video){

        $request->validate([
            'reason' => 'required'
        ]);

        if ($video->status != Video::STATUS_PUBLISHED){
            return response()->json([
                'message' => __('video.video_is_not_published')
            ], 422);
        }

        $option_key = Option::VIDEO_HIDE_REASONS;
        $reasons = json_decode(Option::where("key", $option_key)->first()->value) ?? abort(404);


        if(($key = array_search($request->get('reason'), array_column($reasons, 'key'))) !== false ){
            $video->reason_key = $request->get('reason');
            $video->reason_text = $reasons[$key]->value;
        }else{
            $video->reason_key = 'other';
            $video->reason_text = $request->get('reason');
        }


        $video->status = Video::STATUS_HIDDEN;
        $video->save();

        event(new VideoWasHidden($video));

        return VideoResource::make($video);
    }

    public function unHide(Video $video)
    {
        $video->reason_key = null;
        $video->reason_text = null;
        $video->status = Video::STATUS_PUBLISHED;
        $video->save();

        event(new VideoWasUnHidden($video));

        return VideoResource::make($video);
    }

    public function related_videos($id_or_url_hash)
    {
        $video = Video::published()->where('id', $id_or_url_hash)->orWhere('url_hash', $id_or_url_hash)->first();

        abort_if(is_null($video), 404);

        $query = Video::published()->where("id", "!=", $video->id);

        $tags = $video->tags()->pluck('id')->toArray();
        $category = $video->category ? $video->category->id : null;

        if(!$category && !count($tags)){

            $query->where('channel_id', $video->channel_id);$videos = $query->withoutGlobalScope(OrderDescScope::class)->orderBy('published_at', 'desc')->paginate();$videos->load(['channel'])->append(['is_bookmarked']);return VideoResource::collection($videos);

            return VideoResource::collection(new Paginator([],15));
        }

        $query->where(function ($query) use ($tags, $category){

            if($category){
                $query->whereHas('category', function($q) use ($category){
                    $q->where('id', $category);
                });
            }

            if( count($tags) ){
                $query->orWhereHas('tags', function($q) use ($tags){
                    $q->whereIn('id', $tags);
                });
            }
        });

        $videos = $query->withoutGlobalScope(OrderDescScope::class)->orderBy('published_at', 'desc')->paginate();

        $videos->load(['channel'])->append(['is_bookmarked']);

        return VideoResource::collection($videos);
    }

    public function increase_view($idOrUrlHash)
    {
        $video = Video::published()->where('id', $idOrUrlHash)->orWhere('url_hash', $idOrUrlHash)->firstOrFail();
        $video->view_count++;
        $video->save();

        event(new VideoViewed($video, auth('api')->user()));

        return $video->view_count;
    }

    public function watchTimeStore(WatchTimeStore $request, $videoId)
    {
        $video = Video::published()->where('id', $videoId)->firstOrFail();
        $userID = auth('api')->check()? auth('api')->id(): $request->get('session_id');
        $user = auth("api")->user();
        $originalStart = $request->get("start_time");
        $originalEnd = $request->get("end_time");

        Cache::put("watchtime_user{$userID}_last_updated_at", Carbon::now(), WatchTimeMongo::LastRowCachePeriod);

        $incomingWatchTime = new WatchTimeMongo();
        $incomingWatchTime->video_id = $video->id;
        $incomingWatchTime->user_id = $userID;
        $incomingWatchTime->start_time = $originalStart;
        $incomingWatchTime->end_time = $originalEnd;

        $allWatchTimes = Cache::remember("watchtime_user{$userID}_video{$video->id}", WatchTimeMongo::AllRowsCachePeriod , function () use ($userID, $video){
            return WatchTimeMongo::
                where('user_id', $userID)
                ->where('video_id', $video->id)
                ->get();
        });
        $oldDuration = $allWatchTimes->sum('end_time') - $allWatchTimes->sum('start_time');
        $allWatchTimes->push($incomingWatchTime);


        $newRecords = collect([]);
        foreach ($allWatchTimes as $row)
        {
            $filteredRecords = $newRecords->filter(function ($item) use ($row){
                return
                    ($item->start_time <= $row->start_time && $row->start_time <= $item->end_time)
                    || ($item->start_time <= $row->end_time && $row->end_time <= $item->end_time)
                    || ($item->start_time >= $row->start_time && $row->end_time >= $item->end_time);
            });

            if (!$filteredRecords->isEmpty()){
                $newRecords = $newRecords->filter(function ($value) use ($filteredRecords) {
                    $return = true;
                    foreach ($filteredRecords as $filteredRecord){
                        if($value->start_time == $filteredRecord->start_time
                            && $value->end_time == $filteredRecord->end_time){$return = false;}
                    }
                    return $return;
                });
                $row->start_time = min($filteredRecords->min('start_time'), $row->start_time);
                $row->end_time = max($filteredRecords->max('end_time'), $row->end_time);
            }

            $newRecords->push($row);
        }

        $newRecords->sortBy('start_time');
        $newDuration = $newRecords->sum('end_time') - $newRecords->sum('start_time');

        // Prepare to insert
        $data = [];
        foreach ($newRecords as $newRecord){
            $data[] = [
                'video_id' => $video->id,
                'user_id' => $userID,
                'start_time' => $newRecord->start_time,
                'end_time' => $newRecord->end_time,
                'created_at' => WatchTimeMongo::fromDateTime(Carbon::now()),
                'updated_at' => WatchTimeMongo::fromDateTime(Carbon::now()),
            ];
        }
        // Remove Olds and add new records
        WatchTimeMongo::where('user_id', $userID)->where('video_id', $video->id)->delete();
        WatchTimeMongo::insert($data);

        Cache::put("watchtime_user{$userID}_video{$video->id}", $newRecords, WatchTimeMongo::AllRowsCachePeriod);

        $duration = $newDuration - $oldDuration;

        $video->watch_time += $duration;
        $video->save();

        if ($user){
            $user->watch_time += $duration;
            $user->save();
        }

        event(new VideoWatched($video, $user, $originalStart, $originalEnd));

        return response()->json(["message" => "ok"]);
    }

}
