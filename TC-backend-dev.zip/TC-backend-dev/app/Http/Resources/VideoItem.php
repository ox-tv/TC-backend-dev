<?php

namespace App\Http\Resources;

use App\Http\Resources\Category\CategoryCollection;
use App\Http\Resources\Category\CategoryItem;
use App\Http\Resources\CryptoCurrency\CryptoCurrencyResource;
use App\Models\Video;
use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Facades\Storage;


class VideoItem extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        $withComments = in_array('comments', explode(',', $request->get('include', '')));
        $withRelated = in_array('related', explode(',', $request->get('include', '')));

        return [
            'id' => $this->id,
            'title' => $this->title,
            'description' => $this->description,
            'slug' => $this->slug,
            'url' => $this->file_url? : Storage::disk('videos')->url($this->file_path),
            'url_hash' => $this->url_hash,
            'thumbnail' => $this->thumbnail_url? :$this->thumbnail,
            'thumbnails' => $this->thumbnail_url? getThumbnails($this->thumbnail_url):[],
            'rating' => (float)$this->rating,
            'view_count' => $this->view_count,
            'comment_count' => $this->comments()->count(),
            'likes_count' => $this->likedBy()->count(),
            'dislikes_count' => $this->dislikedBy()->count(),
            'is_liked' => $this->is_liked,
            'is_disliked' => $this->is_disliked,
            'is_bookmarked' => $this->is_bookmarked,
            'duration' => $this->duration,
            'watch_time' => $this->watch_time,
            'status' => $this->status ? Video::STATUS_TEXT[$this->status] : null,
            'user' => new UserItem($this->user),
            'channel' => new ChannelSummaryItem($this->channel),
            'categories' => CategoryCollection::make($this->categories),
            'crypto_currencies' => CryptoCurrencyResource::collection($this->crypto_currencies),
            'category' => CategoryItem::make($this->category),
            'tags' => $this->tags->map(function($tag){ return $tag->name; }),
            'playlists' => $this->playlists,
            'related_videos' => $this->when($withRelated, VideoSummaryCollection::make($this->related_videos)),
            'comments' => $this->when($withComments ,VideoCommentCollection::make($this->comments()->paginate(50))->response()->getData(true)),
            'created_at' => $this->created_at,
            'published_at' => $this->published_at,
            'updated_at' => $this->updated_at,
            'deleted_at' => $this->deleted_at,
        ];
    }
}
