<?php

namespace App\Http\Resources\WatchTime;

use App\Http\Resources\User\UserResource;
use App\Models\Tag;
use Illuminate\Http\Resources\Json\JsonResource;

class WatchTimeResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            // Main attributes
            'id' => $this->id,
            'video_id' => $this->video_id,
            'user_id' => $this->user_id,
            'start_time' => $this->start_time,
            'end_time' => $this->end_time,
            'created_at' => $this->created_at,
        ];
    }
}
