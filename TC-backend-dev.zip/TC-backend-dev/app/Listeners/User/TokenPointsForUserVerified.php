<?php

namespace App\Listeners\User;

use App\Events\UserVerified;
use App\Models\TokenPoint;
use App\Models\WAFSuspiciousIPAddress;
use App\Repository\Eloquent\TokenPointRepository;
use Carbon\Carbon;

class TokenPointsForUserVerified
{
    private $tokenPointRepository;

    public function __construct(TokenPointRepository $tokenPointRepository)
    {
        $this->tokenPointRepository = $tokenPointRepository;
    }

    public function handle(UserVerified $event)
    {
        if (WAFSuspiciousIPAddress::isExistsIP(getClientIP())){
            return;
        }

        $user = $event->user;
        $referrer = $user->referrer;

        if (!$referrer){
            return;
        }

        if ($referrer->channel){
            $this->tokenPointRepository->add([
                'user_id' => $referrer->id,
                'type' => TokenPoint::TYPE_REFERRER_AS_PUBLISHER,
                'amount' => config('points.token.referrer_as_publisher'),
            ]);
            $this->tokenPointRepository->add([
                'user_id' => $user->id,
                'type' => TokenPoint::TYPE_REFERRAL_VIA_PUBLISHER,
                'amount' => config('points.token.referral_via_publisher'),
            ]);
        }else{
            $type = $referrer->is_hero? TokenPoint::TYPE_REFERRER_AS_HERO : TokenPoint::TYPE_REFERRER;
            $amount = $referrer->is_hero? config('points.token.referrer_as_hero') : config('points.token.referrer');
            // Check user get max 5 token point for referral

            $referrerTokenPoint = TokenPoint::where('user_id', intval($referrer->id))
                ->where('type', $type)
                ->where('date', Carbon::now()->startOfDay())
                ->first();

            if ($referrerTokenPoint && $referrerTokenPoint->amount < $amount * 5 ) {
                $this->tokenPointRepository->add([
                    'user_id' => $referrer->id,
                    'type' => $type,
                    'amount' => $amount,
                ]);
            }
        }

        return;
    }
}
