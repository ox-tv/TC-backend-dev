<?php

namespace App\TCNotification\Channels;

class TCMailChannel
{
    public function send($notifiables, $notification)
    {

    }
}
